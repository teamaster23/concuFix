package wrongLock;

/**
 * @author Xuan
 * Created on 2005-1-18
 */
public class Data {

    public int value;
    public Data() {
    	value=0;
    }
}
