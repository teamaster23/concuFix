package replicated_workers.util;

// Author: Matt Dwyer
public final class StandardBarrier {
  private long participants;
  private long numBlocked, numReleased;
  private boolean allBlocked, allReleased;

  public StandardBarrier(long initial) { 
    participants = initial; 
    numReleased = numBlocked = 0; 
  }

private synchronized void blockAll() {
    ++numBlocked;
    if (numBlocked < participants) {
       while (numBlocked < participants) {
           try { wait(); } catch (InterruptedException ex) {}
       }
       allBlocked = true;
       notifyAll();
     }
     allBlocked = false;
     numBlocked = 0;
 }
 private synchronized void releaseAll() {
    ++numReleased;
    if (numReleased < participants) {
      while (numReleased < participants) {
          try { wait(); } catch (InterruptedException ex) {}
      }
      allReleased = true;
      notifyAll();
    }
    allReleased = false;
    numReleased = 0;
 }

  public synchronized void await() {
    blockAll();
    releaseAll();
  }
}
