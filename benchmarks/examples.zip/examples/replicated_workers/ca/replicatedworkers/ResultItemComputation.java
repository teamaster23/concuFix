package replicated_workers.ca.replicatedworkers;

public interface ResultItemComputation {
  public abstract boolean doResults();
}


