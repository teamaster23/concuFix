package replicated_workers.apps.AdaptiveQuadrature;

import replicated_workers.ca.replicatedworkers.Collection;
import java.util.Vector;

class FIFOCollection extends Vector implements Collection
{
  public final Object take()
  {
    Object tmp; 
    tmp = firstElement();
    removeElementAt(0);
    return tmp;
  }
}


