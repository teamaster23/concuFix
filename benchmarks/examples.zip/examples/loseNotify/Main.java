package loseNotify;
public class Main {
    static int iWait=1;
    static int iNotify=1;
    static int iterations=12;
    public void run() {
    	Losenotify ln=new Losenotify();    
    	for (int i=0;i<iWait;i++) {
            new WaitThread(ln,iterations).start();
        }
        try {
            Thread.sleep(50);  // Ensure wait threads start first
        } catch (InterruptedException e) {}
        for (int i=0;i<iNotify;i++)
            new NotifyThread(ln,iterations).start();
    }
    public static void main(String[] args) {
//	if (args.length < 3){
//	    System.out.println("ERROR: Expected 3 parameters");
//	}else{
	    iWait= 2;//Integer.parseInt(args[0]);
	    iNotify= 2;//Integer.parseInt(args[1]);
	    iterations=2;// Integer.parseInt(args[2]);
	    Main t= new Main();
	    t.run();
	}
    //}
}
