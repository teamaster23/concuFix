package loseNotify;
public class WaitThread extends Thread {
    Losenotify ln;
    int iterations;
    public WaitThread(Losenotify ln, int iterations) {
     	this.ln=ln;
     	this.iterations=iterations;
     }
     public void run() {
		for (int i=0;i<iterations;i++) {
			ln.towait();
		}

     }
}
