package loseNotify;
public class Losenotify {
    static public Object monitor_=new Object();
    public  void towait() {
	try {
		synchronized (monitor_) {
			monitor_.wait();
		}
	}catch (Exception e) {}
    }
    public  void tonotify() {
    	try {
			synchronized (monitor_) {
				monitor_.notifyAll();
			}
	}catch (Exception e) {}
    }
}
