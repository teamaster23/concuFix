package twoStage;
public class Data {
    public int value;
    public Data() {
    	value=0;
    }
}
