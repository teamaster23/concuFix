package elevator;
public class DoorClosedException extends Exception {
   public DoorClosedException() {
   }
}