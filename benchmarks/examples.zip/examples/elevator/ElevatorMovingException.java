package elevator;
public class ElevatorMovingException  extends Exception {
   public ElevatorMovingException() {
   }
}