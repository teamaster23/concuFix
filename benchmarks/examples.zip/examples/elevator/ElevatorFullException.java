package elevator;
public class ElevatorFullException extends Exception {
   public ElevatorFullException() {
   }
}