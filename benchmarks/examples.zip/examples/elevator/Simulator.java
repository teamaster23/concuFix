package elevator;
import java.util.*;
public class Simulator  {
   public static boolean debug = false;
   public static final int MAX_PEOPLE = 2; 
   public static final int MAX_TIME = 60;
   private static volatile int counter;
   public static void stopProgram(){
      counter = MAX_TIME;
   }
   public static int getTimeRemaing(){
       return (MAX_TIME - counter)/2;
   }
   public static int getElapsedTime(){
       return counter/2;
   }
   public static void main(String[] args)  {
      Thread.currentThread().setPriority(Thread.NORM_PRIORITY+2);
      Vector people = new Vector();
      Building b = new Building();
      Person.setBuilding(b);
      for(int i = 0; i < MAX_PEOPLE; i++){
         Person p = new Person(i+1);
         people.add(p);
         p.start();
      }
      for(int i = 0; i < people.size(); i++){
         ((Person)people.get(i)).setStopRunning();
      }
      b.stopElevators();
    }
} 
