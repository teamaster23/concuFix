package checkfield;

public class InstanceExample {
	public static InstanceExample instance = new InstanceExample();
	public int number;
	public int num2;
}
