package clean;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Event {
    public int count = 0;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition condition = lock.newCondition();
     public void waitForEvent(int remote_count) {
        lock.lock();
        try {
            while (remote_count == count) {
                condition.await();
            }
         } catch (InterruptedException e) {
             Thread.currentThread().interrupt();
         } finally {
             lock.unlock();
         }
     }
     public void signal_event() {
         lock.lock();
         try {
             count = (count + 1) % 100;
             condition.signalAll();
         } finally {
             lock.unlock();
         }
     }

}
